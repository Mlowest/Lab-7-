# -*- coding: utf-8 -*-
"""
Created on Tue Aug 23 23:53:06 2022

@author: Michael Low
"""

from PIL import Image
image = Image.open(r"balloon.png")
image = image.resize((88,150),Image.ANTIALIAS)
image.save(fp="balloon88.png")

#image = Image.open("orange.png")
#image = image.resize((32,32),Image.ANTIALIAS)
#image.save(fp="orange32x32.png")

#image = Image.open("pineapple.png")
#image = image.resize((32,32),Image.ANTIALIAS)
#image.save(fp="pineapple32x32.png")